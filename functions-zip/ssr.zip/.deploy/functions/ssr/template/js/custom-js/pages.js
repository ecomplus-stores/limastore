// Add your custom JavaScript for storefront pages here.
/* if(window.innerWidth > 992) {
  window.addEventListener('scroll',(event) => {
    if(document.querySelector('.header').offsetTop > 60) {
      document.querySelector('.header').style.background = '#fff';
      document.querySelector('.header').style.paddingTop = '0';
    } else {
      console.log('estou aqui')
      console.log(document.querySelector('.header').offsetTop)
      document.querySelector('.header').style.background = 'none !important'
      document.querySelector('.header').style.paddingTop = '20px';
    }
  })
} */
